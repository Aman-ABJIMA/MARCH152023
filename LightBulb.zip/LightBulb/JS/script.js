let btn = document.getElementById('btn');
let bulb = document.getElementById('bulb');
btn.addEventListener('click',onBulb);

function onBulb(event)
{
    if(btn.textContent.includes('Turn On'))
    {
       bulb.src = "/light-bulb-4514505__340.webp";
       bulb.style.width="533px";
       btn.textContent = "Turn Off";
    }
    else
    {
        bulb.src = "/depositphotos_23575953-stock-photo-light-bulb.jpg";
        bulb.style.width="300px";
        btn.textContent = "Turn On";
    }
}